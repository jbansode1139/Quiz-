package jyoti.rv.quizzz.model;

public interface UserOwned {
	User getUser();
}
