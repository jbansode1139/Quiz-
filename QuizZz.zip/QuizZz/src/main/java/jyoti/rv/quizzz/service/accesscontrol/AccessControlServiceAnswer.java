package jyoti.rv.quizzz.service.accesscontrol;

import org.springframework.stereotype.Service;

import jyoti.rv.quizzz.model.Answer;

@Service
public class AccessControlServiceAnswer extends AccessControlServiceUserOwned<Answer> {

}
