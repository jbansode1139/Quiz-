package jyoti.rv.quizzz.service.usermanagement.token;

import org.springframework.scheduling.annotation.Async;

import jyoti.rv.quizzz.model.TokenModel;
import jyoti.rv.quizzz.model.TokenType;
import jyoti.rv.quizzz.model.User;

public interface TokenDeliverySystem {
	@Async
	void sendTokenToUser(TokenModel token, User user, TokenType tokenType);
}
